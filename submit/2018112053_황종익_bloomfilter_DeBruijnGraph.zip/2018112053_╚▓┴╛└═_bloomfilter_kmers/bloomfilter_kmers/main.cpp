// 2018112053 Ȳ����

#include <iostream>
#include <vector>
#include <math.h>
#include <unordered_set>
#include <fstream>
#include <string>
#include <list>
#include <map>
#include <array>
#include <sstream>
#include <time.h>
#include "MurmurHash3.h"
#define shortReadLen 100
#define maxBreadth 90000
#define maxDepth 90000
using namespace std;

string maxLenDNA;

namespace Generator {
	const vector<string> BASES = { "A", "T", "C", "G" };

	vector<string> genExtensions(string kmer)
	{
		vector<string> E;

		unsigned long kmerSize = kmer.size();
		for (string b : BASES)
		{
			E.push_back(b + kmer.substr(0, kmerSize - 1));
			E.push_back(kmer.substr(1) + b);
		}
		
		return E;
	}

	vector<string> genLeftExtensions(string kmer)
	{
		vector<string> E;

		unsigned long kmerSize = kmer.size();
		for (string b : BASES)
		{
			E.push_back(b + kmer.substr(0, kmerSize - 1));
		}

		return E;
	}

	vector<string> genRightExtensions(string kmer)
	{
		vector<string> E;

		unsigned long kmerSize = kmer.size();
		for (string b : BASES)
		{
			E.push_back(kmer.substr(1) + b);
		}

		return E;
	}

	string extLastKmerInSeq(string sequence, int k)
	{
		return sequence.substr(sequence.size() - k);
	}

	string extFirstKmerInSeq(string sequence, int k)
	{
		return sequence.substr(0, k);
	}

}

namespace measures
{
	float measure_n50(vector<int> lengths)
	{
		map<int, int> freq;
		
		for (int i : lengths)
			freq[i] = freq[i] + 1;

		vector<int> tmpLengths;

		for (const auto& p : freq)
		{
			int key = p.first;
			int value = p.second;

			for (int i = 0; i < value * key; i++)
				tmpLengths.push_back(key);
		}

		size_t size = tmpLengths.size();

		if (size % 2 == 0) 
			return (tmpLengths[size / 2 - 1] + tmpLengths[size / 2]) / 2.;
		else
			return tmpLengths[size / 2];
	}

	vector<int> read_seq_counts(string inputpaths)
	{
		ifstream in(inputpaths);

		vector<int> counts;
		string delimiter = "����: ";

		string line;
		while (getline(in, line))
		{
			if (line[0] >= '0' && line[0] <= '9')
			{
				string token = line.substr(line.find(delimiter) + delimiter.size());
				//cout << "token : " << token << "\n";
				counts.push_back(stoi(token));
			}
		}

		in.close();
		return counts;
	}
}

class BloomFilter
{
	int numHash;
	vector<bool> bits;

public:
	BloomFilter(int size, int numHash) : bits(size), numHash(numHash) {}

	BloomFilter(unsigned int mer_counts, int k)
	{
		int filterSize = calc_filter_size(mer_counts, k);
		int numHashFunctions = calc_numOf_hashfunctions(filterSize, mer_counts);
		cout << "filterSize : " << filterSize << " numHashFunctions : " << numHashFunctions << "\n";
		/*string s;
		cin >> s;*/
		// ���� ������ ����
		while (filterSize % numHashFunctions != 0)
			filterSize++;

		new (this) BloomFilter(filterSize, numHashFunctions);
	}

	void add(const string s)
	{
		array<uint64_t, 2> hashes = hash(&s);
		//cout << "s : " << s << "\n";
		for (int n = 0; n < numHash; n++)
		{
			bits[mixHash(n, hashes[0], hashes[1], this->bits.size())] = true;
		}
		//cout << "\n\n";
	}

	bool contains(const string s)
	{
		array<uint64_t, 2> hashes = hash(&s);
		//cout << "contains s : " << s << "\n";
		for (int n = 0; n < this->numHash; n++)
		{
			if (bits[mixHash(n, hashes[0], hashes[1], this->bits.size())] == false)
			{
				return false;
			}
		}
		//cout << "\n";
		return true;
	}

	unsigned long byteSize()
	{
		return bits.size();
	}

private:
	array<uint64_t, 2> hash(const string* s)
	{
		array<uint64_t, 2> hashes;
		uint32_t seed = 420;
		MurmurHash3_x64_128(s->c_str(), (int)s->size(), seed, hashes.data());
		return hashes;
	}

	uint64_t mixHash(uint8_t n, uint64_t hashA, uint64_t hashB, uint64_t filterSize)
	{
		uint64_t h = (hashA + n * hashB) % filterSize;
		return h;
	}

	int calc_filter_size(int kmerSize, int k)
	{
		return (int)(1.44 * kmerSize * log2(1 / (2.08 / (16 * k))));
	}
	int calc_numOf_hashfunctions(int filterSize, float kmerSize)
	{
		return (int)filterSize / kmerSize * log(2);
	}
};

class DeBruijnGraph
{
public:
	DeBruijnGraph(string inputPath, unsigned int mer_counts, int k)
		: k(k), bloomFilter(mer_counts, k)
	{
		initBloomFilter(inputPath);
		findCriticalFP(inputPath);
	}
	
	void traversal(string inputPath, string outputPath, bool ignoreWords)
	{
		cout << "�׷��� ��ȸ ��...\n";

		unordered_set<string> initKmers;
		ifstream in(inputPath);

		string line;
		//string delimiter = "��° contig, ����: ";
		while (getline(in, line))
		{
			if (ignoreWords)
				getline(in, line);

			//vector<string> leftExtensions = Generator::genLeftExtensions(Generator::extFirstKmerInSeq(line, k));
			vector<string> leftExtensions = Generator::genLeftExtensions(line);

			int index = 0;
			for (string e : leftExtensions)
			{
				if (isBelongsToDebruijnGraph(e))
					index++;
			}
			if (index == 0) 
			{
				initKmers.insert(line);
			}
		}

		in.close();

		unsigned long initKmersSize = initKmers.size();
		cout << "initKmersSize : " << initKmersSize << "\n";
		int kmerIndex = 1;

		unordered_set<string> contigs; 
		unordered_set<string> marked; 
		for (string start : initKmers)
		{
			cout << "Starting kmer: " << start << ", ���൵ : " << kmerIndex++ << "/" << initKmersSize << "\n";
			list<string> paths;
			paths.push_back(start);

			int depth = 0; 
			while (paths.size() > 0)
			{
				if (depth >= maxDepth)
				{
					contigs.insert(paths.back());
					break;
				}

				list<string> pathsBeAdd;
				list<string> pathsBeRemove;

				int breadth = paths.size();
				if (breadth == 1)
				{
					for (string& path : paths)
					{
						string lastKmer = Generator::extLastKmerInSeq(path, k);
						/*cout << "lastKmer : " << lastKmer << " size : " << lastKmer.size() << "\n";*/
						marked.insert(lastKmer);

						vector<string> ext = Generator::genRightExtensions(lastKmer);
						vector<string> validExt;
						for (string e : ext)
						{
							if (isBelongsToDebruijnGraph(e) && marked.count(e) == 0)
							{
								validExt.push_back(e);
							}
						}

						unsigned long validExtCnt = validExt.size();
						if (validExtCnt == 0)
						{
							contigs.insert(path);
							pathsBeRemove.push_back(path);
						}
						else if (validExtCnt == 1)
						{
							char& lastChar = validExt[0].back();
							path.push_back(lastChar);
						}
						else
						{
							contigs.insert(path);
							pathsBeRemove.push_back(path);
							for (string validE : validExt)
							{
								//cout << "pathsBeAdd from : " << path << " to : " << validE << "\n";
								pathsBeAdd.push_back(validE);
							}
							depth++;
						}
					}
				}
				else
				{
					depth++;
					for (string& path : paths)
					{
						string lastKmer = Generator::extLastKmerInSeq(path, k);
						//cout << "lastKmer : " << lastKmer << "\n";
						marked.insert(lastKmer);

						vector<string> ext = Generator::genRightExtensions(lastKmer);
						vector<string> validExt;
						for (string e : ext)
						{
							if (isBelongsToDebruijnGraph(e) && marked.count(e) == 0)
								validExt.push_back(e);
						}

						string pathClone(path);
						unsigned long validExtCnt = validExt.size();
						if (validExtCnt == 0)
						{
							pathsBeRemove.push_back(path);
						}
						else if (validExtCnt == 1)
						{
							char& lastChar = validExt[0].back();
							path.push_back(lastChar);
						}
						else
						{
							for (string validE : validExt)
							{
								char& lastChar = validE.back();
								string newPath(pathClone);
								newPath.push_back(lastChar);
								pathsBeAdd.push_back(newPath);
							}
						}
					}
				}

				for (string p : pathsBeRemove)
					paths.remove(p);

				if (paths.size() == 1)
					depth = 0;

				for (string p : pathsBeAdd)
				{
					if (paths.size() >= maxBreadth)
						break;
					paths.push_back(p);
				}
			}
		}

		ofstream output;
		output.open(outputPath);
		int outputIndex = 0;
		for (string contig : contigs)
		{
			/*if (contig.length() < 2 * shortReadLen + 1) continue;*/

			output << outputIndex++ << "��° contig, ����: " << contig.size() << "\n";
			if (contig.size() > maxLenDNA.size())
				maxLenDNA = contig;
			output << contig << "\n";
		}
		
		output.close();
	}

	unsigned long byteSize()
	{
		unsigned long size = 0;
		size += bloomFilter.byteSize();
		size += criticalFP.size() * k;
		return size;
	}

private:
	int k;
	BloomFilter bloomFilter;
	unordered_set<string> criticalFP; // critical false positive(���� ����)

	void initBloomFilter(string inputPath)
	{
		cout << "���� ���� ������...\n";
		unordered_set<string> kmers = loadKmers(inputPath);

		for (string kmer : kmers)
			bloomFilter.add(kmer);
	}

	void findCriticalFP(string inputPath)
	{
		cout << "���� �������� ã�Ƴ��� �ֽ��ϴ�...\n";

		unordered_set<string> S = loadKmers(inputPath);
		unordered_set<string> P = findP(S);

		for (string p : P)
		{
			if (S.find(p) == S.end())
				criticalFP.insert(p);
		}
	}

	unordered_set<string> findP(unordered_set<string>& S)
	{
		unordered_set<string> P;

		for (string s : S)
		{
			vector<string> E = Generator::genExtensions(s);
			for (string e : E)
			{
				if (bloomFilter.contains(e))
					P.insert(e);
			}
		}

		return P;
	}

	bool isBelongsToDebruijnGraph(string kmer)
	{
		//cout << kmer << " bloomFilter.contains(kmer) : " << bloomFilter.contains(kmer) << "\n";
		return bloomFilter.contains(kmer) && criticalFP.count(kmer) == 0;
	}

	unordered_set<string> loadKmers(string path)
	{
		ifstream in(path);

		unordered_set<string> S;
		string line;
		while (getline(in, line))
		{
			S.insert(line);
		}
		in.close();

		return S;
	}
};

vector<string> read_mers(string inputPath, bool ignoreWords)
{
	ifstream in(inputPath);
	vector<string> mers;
	//string delimiter = "��° contig, ����: ";

	string line;
	while (getline(in, line))
	{
		if(ignoreWords)
			getline(in, line);
		mers.push_back(line);
	}

	in.close();
	return mers;
}

void make_mers(string inputPath, string outputPath, int k, bool ignoreWords)
{
	ifstream in(inputPath);
	ofstream out(outputPath);
	
	string line;
	string delimiter = "��° contig, ����: ";
	while (getline(in, line))
	{
		int startIdx = 0;
		int lengthOfline = line.size();
		if (ignoreWords == false)
		{
			while (startIdx + k <= lengthOfline)
			{
				out << line.substr(startIdx++, k) << "\n";
			}
		}
		else
		{
			getline(in, line);
			if (k <= lengthOfline)
			{
				out << line.substr(0, k) << "\n";
				out << line.substr(line.size() - k) << "\n";
			}
		}
	}

	in.close();
	out.close();
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	clock_t start = clock();
	int k; // k-mer�� ����
	
	string mainPath = "C:/texts/texts/";
	string inputPath = mainPath + "shortRead.txt";
	string kmerPath = mainPath + "kmersRead.txt";
	string outputPath = mainPath + "restoredContigs.txt";
	bool calcN50 = true; // n50�� ������ �ʴ� ��쿡�� false�� ����ϴ� �� ����.
	
	string tmp;
	ifstream in(inputPath);
	getline(in, tmp);
	if (tmp.size() > 50)
		k = 24;
	else if (tmp.size() > 25)
		k = 15;
	else if (tmp.size() > 10)
		k = 7;
	else if (tmp.size() > 0)
		k = 3;

	make_mers(inputPath, kmerPath, k, false);
	vector<string> kmers = read_mers(kmerPath, false);
	cout << "kmers�� ��: " << kmers.size() << "\n";
	DeBruijnGraph graph = DeBruijnGraph(kmerPath, kmers.size(), k);
	graph.traversal(kmerPath, outputPath, false);


	clock_t end = clock();
	double time = double((double)end - start) / CLOCKS_PER_SEC;
	cout << "�Ҹ� �ð� : " << time << "seconds\n";
	cout << "De Bruijn �׷��� ũ��(����Ʈ) : " << graph.byteSize() << "\n";

	string myDNA;
	string restoredDNA = maxLenDNA;
	unsigned long long cnt = 0;
	float n50_measure, accuracy = 0;
	ifstream in1(mainPath + "my.txt");
	getline(in1, myDNA);

	cout << "\n\n";
	cout << "      ���� myDNA�� ����      :" <<  myDNA.size() << "\n";
	cout << "������ ���� �� contig�� ���� :" << restoredDNA.size() << "\n";

	cnt = myDNA.find(restoredDNA);
	if (cnt < myDNA.size())
		accuracy = double(restoredDNA.size() / (double)myDNA.size()) * 100.0f;
		

	cout << "\n\n������ ������ �Ʒ��� ��Ȯ���� ���� ������ 1/4�������� �����Ǿ��� ���� �ǹ̰� �ִ� ���Դϴ�.\n�׺��� ª�ٸ� �� �Ʒ��� N50���� Ȯ�����ּ���.\nDNA ��ġ�� : " << accuracy << "%\n";
	if (calcN50 == true)
	{
		vector<int> lengths = measures::read_seq_counts(outputPath);
		n50_measure = measures::measure_n50(lengths);
		cout << "N50 : " << n50_measure << "\n";
	}

	if (restoredDNA.size() >= myDNA.size() / 4)
	{
		cout << "(���ǹ��� ��쿡 ���Ѵ�.) DNA ��ġ�� : " << accuracy << "%\n";
	}
	else
	{
		cout << "(���ǹ��� ��쿡 ���Ѵ�.) N50��  ��  : " << n50_measure << "\n";
	}

}