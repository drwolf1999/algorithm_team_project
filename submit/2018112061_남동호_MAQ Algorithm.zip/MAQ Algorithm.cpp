﻿#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <array>
#include <fstream>
#include <chrono>
//2018112061 남동호
void Sub(std::array<char, 100000>& dna, std::string& subString, int index, int type);	//Reference DNA 분할 함수
void Hash(std::string& shortRead, std::string& subString, int type);					//ShortRead 분할 함수
class Timer
{
	using clock_t = std::chrono::high_resolution_clock;
	using second_t = std::chrono::duration<double, std::ratio<1>>;

	std::chrono::time_point<clock_t> start_time = clock_t::now();//생성되면서 시간 측정 시작
public:
	void elapsed() {
		std::chrono::time_point<clock_t> end_time = clock_t::now();//종료시간 저장

		std::cout << std::chrono::duration_cast<second_t>(end_time - start_time).count() << std::endl;//실행시간 출력
	}
};
int main() {
	using namespace std;
	array<char, 100000> refDna;
	array<char, 100000> MyDna;
	string shortRead;
	cout << "Reference Dna 로드 중" << endl;
	ifstream istream("refer.txt");
	for (int i = 0; i < 100000; i++) {	//Reference DNA 불러오기
		istream >> refDna[i];
	}
	istream.close();
	cout << "Reference Dna 로드 완료" << endl;
	unordered_map<string, int> HashTable;	//ShortRead 해쉬테이블
	string sub_length16 = "                ", sub_length24 = "                        ";	//분할 문자열 저장 변수
	istream.open("shortreads.txt");
	int count, idx = 1;
	bool found = false;
	Timer t1;
	while (getline(istream, shortRead)) {
		
			
			cout << "ShortRead 매칭 중.. " << idx++ << endl;
			count = 0;
			HashTable.clear();
			Hash(shortRead, sub_length16, 1);	//테이블 생성
			HashTable[sub_length16] = 1;
			Hash(shortRead, sub_length16, 2);	//테이블 생성
			HashTable[sub_length16] = 2;
			for (int i = 3; i < 15; i++) {		//테이블 생성
				Hash(shortRead, sub_length24, i);
				HashTable[sub_length24] = i;
			}
			for (int i = 0; i < refDna.size() - 33; i++) {	//테이블 검색
				count = 0;
				Sub(refDna, sub_length16, i, 1);
				if (HashTable[sub_length16] == 1)	//검색되면 COUNT
					count++;
				Sub(refDna, sub_length16, i, 2);
				if (HashTable[sub_length16] == 2)	//검색되면 COUNT
					count++;
				if (count == 2) {
					for (int j = 0; j < 32; j++)
						MyDna[i + j] = shortRead[j];
					break;
				}
				for (int j = 3; j < 15; j++) {
					Sub(refDna, sub_length24, i, j);
					if (HashTable[sub_length24] == j)	//검색되면 COUNT
						count++;
					if (count == 2) {
						found = true;
						for (int k = 0; k < 32; k++)
							MyDna[i + k] = shortRead[k];
						break;
					}
				}
				if (found) {
					found = false;
					break;
				}
			}
		
	}
	istream.close();
	cout << "ShortRead 매칭 완료" << endl;
	cout << "실행시간 : ";
	t1.elapsed();
	ofstream ostream("result.txt");
	for (int i = 0; i < 100000; i++)	//myDna 불러오기
		ostream << MyDna[i];
	ostream.close();
	cout << "MyDna 로드 중" << endl;
	istream.open("my.txt");
	for (int i = 0; i < 100000; i++) {
		istream >> refDna[i];
	}
	count = 0;
	cout << "일치율 계산 중.." << endl;
	for (int i = 0; i < 100000; i++)
		if (refDna[i] == MyDna[i])
			count++;
	cout << "일치율 : " << count / 1000.0 << "%" << endl;
	return 0;
}
void Sub(std::array<char, 100000>& dna, std::string& subString, int index, int type) {
	int idx = 0;
	switch (type) {
	case 1:
		for (int i = index; i < 16; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 2:
		for (int i = index + 16; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 3:
		for (int i = index + 4; i < index + 28; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 4:
		for (int i = index; i < index + 12; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 20; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 5:
		for (int i = index; i < index + 12; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 16; i < index + 28; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 6:
		for (int i = index + 4; i < index + 16; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 20; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 7:
		for (int i = index; i < index + 6; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 8; i < index + 14; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 16; i < index + 22; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 24; i < index + 30; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 8:
		for (int i = index + 2; i < index + 8; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 10; i < index + 16; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 18; i < index + 24; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 26; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 9:
		for (int i = index + 2; i < index + 14; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 18; i < index + 30; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 10:
		for (int i = index; i < index + 6; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 10; i < index + 22; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 26; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 11:
		for (int i = index + 1; i < index + 7; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 9; i < index + 15; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 17; i < index + 23; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 25; i < index + 31; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 12:
		subString[idx++] = dna[index];
		for (int i = index + 3; i < index + 9; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 11; i < index + 17; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 19; i < index + 25; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 27; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 13:
		for (int i = index; i < index + 2; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 4; i < index + 10; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 12; i < index + 18; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 20; i < index + 26; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 28; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
		break;
	case 14:
		for (int i = index; i < index + 3; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 5; i < index + 11; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 13; i < index + 19; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 21; i < index + 27; i++, idx++)
			subString[idx] = dna[i];
		for (int i = index + 29; i < index + 32; i++, idx++)
			subString[idx] = dna[i];
	}
}
void Hash(std::string& shortRead, std::string& subString, int type) {
	int idx = 0;
	switch (type) {
	case 1:
		for (int i = 0; i < 16; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 2:
		for (int i = 0 + 16; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 3:
		for (int i = 4; i < 28; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 4:
		for (int i = 0; i < 12; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 0 + 20; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 5:
		for (int i = 0; i < 12; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 16; i < 28; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 6:
		for (int i = 4; i < 16; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 20; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 7:
		for (int i = 0; i < 6; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 8; i < 14; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 16; i < 22; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 24; i < 30; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 8:
		for (int i = 2; i < 8; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 10; i < 16; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 18; i < 24; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 26; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 9:
		for (int i = 2; i < 14; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 18; i < 30; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 10:
		for (int i = 0; i < 6; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 10; i < 22; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 26; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 11:
		for (int i = 1; i < 7; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 9; i < 15; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 17; i < 23; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 25; i < 31; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 12:
		subString[idx++] = shortRead[0];
		for (int i = 3; i < 9; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 11; i < 17; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 19; i < 25; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 27; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 13:
		for (int i = 0; i < 2; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 4; i < 10; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 12; i < 18; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 20; i < 26; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 28; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
		break;
	case 14:
		for (int i = 0; i < 3; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 5; i < 11; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 13; i < 19; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 21; i < 27; i++, idx++)
			subString[idx] = shortRead[i];
		for (int i = 29; i < 32; i++, idx++)
			subString[idx] = shortRead[i];
	}
}