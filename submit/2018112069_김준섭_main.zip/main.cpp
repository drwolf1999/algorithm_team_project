//2018112069 ���ؼ�
#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <fstream>
#include <ctime>
using namespace std;

// combine to strings str1 and str2 by overlap like (ATGC + GCTT => ATGCTT)
string Combine(string str1, string str2, int overlap)
{
	string ret = "";
	ret += str1;
	ret += str2.substr(overlap);
	return ret;
}

// If there are same short reads, remove them for time efficiency
vector<string> RemoveContainedReads(vector<string> reads)
{
	if (reads.size() > 1)
	{
		for (int i = 0; i < reads.size() - 1; ++i)
		{
			for (int j = i + 1; j < reads.size(); ++j)
			{
				if (reads[i].find(reads[j]) != string::npos)
					reads[i] = "TEMP";
				else if (reads[j].find(reads[i]) != string::npos)
					reads[j] = "TEMP";
			}
		}
	}
	vector<string> ret;
	for (int i = 0; i < reads.size(); ++i)
	{
		if (reads[i].compare("TEMP") != 0)
			ret.push_back(reads[i]);
	}
	return ret;
}

// get max overlap by string comparison
string GetMaxOverlap(string str1, string str2, bool& isForward)
{
	string overlap = "";
	isForward = false;

	for (int i = 1; i < str2.length() + 1; ++i)
	{
		if (str1.substr(0, i) == str2.substr(str2.length() - i) && str1.substr(0, i).length() > overlap.length())
		{
			overlap = str1.substr(0, i);
			isForward = false;
		}
	}

	for (int j = 1; j < int(str1.length() - str2.length()) + 1; ++j)
	{
		string subStr1 = str1.substr(j, str2.length());
		if (subStr1 == str2 && subStr1.length() > overlap.length())
		{
			overlap = subStr1;
			isForward = true;
		}
	}
	
	for (int k = 1; k < int(str2.length()) + 1; ++k)
	{
		string subStr2 = str2.substr(0, int(str2.length()) - k);
		string subStr1 = "JUNK";
		if (int(str1.length()) - (int(str2.length()) - k) >= 0)
			string subS1 = str1.substr(int(str1.length()) - (int(str2.length()) - k));
		if (subStr1 == subStr2 && subStr1.length() > overlap.length())
		{
			overlap = subStr1;
			isForward = true;
		}
	}
	
	return overlap;
}

// merge short reads by max overlap
vector<string> ReconstructDNA(vector<string> reads, int threshold)
{
	map<int, vector<pair<string, string> > > overlapVec;
	set<string> closedSet;
	vector<string> combinedReads;

	for (int i = 0; i < reads.size() - 1; ++i)
	{
		for (int j = i + 1; j < reads.size(); ++j)
		{
			bool isForward = false;
			string maxOverlap = GetMaxOverlap(reads[i], reads[j], isForward);

			if (overlapVec.find(maxOverlap.length()) != overlapVec.end())
			{
				if (isForward)
					overlapVec[maxOverlap.length()].push_back(pair<string, string>(reads[i], reads[j]));
				else
					overlapVec[maxOverlap.length()].push_back(pair<string, string>(reads[j], reads[i]));
			}
			else
			{
				if (isForward)
					overlapVec[maxOverlap.length()].push_back(pair<string, string>(reads[i], reads[j]));
				else
					overlapVec[maxOverlap.length()].push_back(pair<string, string>(reads[j], reads[i]));
			}
		}
	}

	vector<int> overlaps;
	for (map<int, vector<pair<string, string> > >::iterator it = overlapVec.begin(); it != overlapVec.end(); ++it)
	{
		overlaps.push_back(it->first);
	}
	sort(overlaps.begin(), overlaps.end(), greater<>());

	for (int overlap : overlaps)
	{
		for (int i = 0; i < overlapVec[overlap].size(); ++i)
		{
			string str1 = overlapVec[overlap][i].first;
			string str2 = overlapVec[overlap][i].second;

			if (overlap >= threshold && closedSet.find(str1) == closedSet.end() && closedSet.find(str2) == closedSet.end())
			{
				closedSet.insert(str1);
				closedSet.insert(str2);
				combinedReads.push_back(Combine(str1, str2, overlap));
			}
		}
	}

	for (string item : reads)
	{
		if (closedSet.find(item) == closedSet.end())
		{
			combinedReads.push_back(item);
		}
	}
	return combinedReads;
}

int main()
{
	clock_t start = clock();
	string filename = "C:/Users/junes/OneDrive/���� ȭ��/TTEMPTEMTPEMTPETMEPTEPTM/shortread.txt";
	vector<string> reads;
	reads.clear();
	ifstream file(filename);
	string temp;
	while (getline(file, temp))
	{
		reads.push_back(temp);
	}

	int prev = -1, threshold = 99;
	int iter = 0;
	while (reads.size() != 1)
	{
		cout << "\r" << iter++;
		if (reads.size() == prev) // if there is no merge, then subtract threshold by 1
		{
			threshold -= 1;
		}
		prev = reads.size();
		reads = ReconstructDNA(RemoveContainedReads(reads), threshold);
	}

	cout << "\nLENGTH: " << reads[0].length() << "\n";
	cout << reads[0];
	file.close();

	ofstream file2("C:/Users/junes/OneDrive/���� ȭ��/TTEMPTEMTPEMTPETMEPTEPTM/9_10000_100_2000_1_th99.txt"); // save result to text file
	ifstream file3("C:/Users/junes/OneDrive/���� ȭ��/TTEMPTEMTPEMTPETMEPTEPTM/my.txt"); // myDNA text file
	string myDNA = "";
	getline(file3, myDNA);

	// calculate accuracy
	long long smallLength = myDNA.length();
	if (reads[0].length() < smallLength)
	{
		smallLength = reads[0].length();
	}
	double accuracy = 0;
	long long count = 0;
	for (int i = 0; i < smallLength; ++i)
	{
		if (reads[0][i] == myDNA[i])
			count++;
	}
	accuracy = double(count) / double(smallLength) * 100.0;

	// time
	clock_t end = clock();
	double diff = (end - start) / CLOCKS_PER_SEC;

	// save data to file
	file2 << "My Length: " << reads[0].length() << ", DNA Length: " << myDNA.length() << "\n";
	file2 << "Accuracy: " << accuracy << "\n";
	file2 << "Time: " << diff << "\n";
	file2 << reads[0];

	file2.close();
	file3.close();
	
}